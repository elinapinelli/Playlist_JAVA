#include "Song.h"
using namespace std; //gia na doulepsei string, to_string
#include <string>//gia na doulepsei string
#include "Artist.h"

Song::Song(int ID, string t, Artist aL[3], Artist l, int d,double r, string g) {//B.b.1 Constructor
	uniqueSongID=ID;
	title=t;
	// artistList=aL;
	lyricist=l;
	duration=d;
	rating=r;
	genre=g;	
	setArtistList(aL);
}
Song::Song(){//empty constructor

}

void Song::setUniqueSongID(int ID) {
	uniqueSongID=ID;
}

int Song::getUniqueSongID() {
	return uniqueSongID;
}

void Song::setTitle(std::string t) {
	title=t;
} 

string Song::getTitle() {
	return title;
}

void Song::setArtistList(Artist aL[3]) {
	for(int i=0;i<3;i++){//epeidi sthn C den mporoyme na thesoume enan pinaka iso me enan allon, thetoume tis kathe grammes
		artistList[i]=aL[i];
	}
}

Artist* Song::getArtistList() {
	return artistList;
}

void Song::setLyricist( Artist l) {
	lyricist=l;
}

 Artist Song::getLyricist() {
	return lyricist;
}

void Song::setDuration(int d) {
	duration=d;
}

int Song::getDuration() {
	return duration;
}

void Song::setRating(double r) {
	rating=r;
}

double Song::getRating() {
	return rating;
}

void Song::setGenre(std::string g) {
	genre=g;
}

string Song::getGenre() {
	return genre;
}
string Song::toString() {	
	string to_str="Id: "+to_string(uniqueSongID)+", Title: "+title+", Artists: ["	;
	for(int i=0;i<3;i++){// for each artist
		if(artistList[i].getFirstName()!="" && artistList[i].getLastName()!=""){//if artist exists
			if(i>0){//not first artist
				to_str=to_str+", "+artistList[i].toString();
			}
			else{//first artist
				to_str=to_str+artistList[i].toString();
			}
			
		}
	}	
	to_str=to_str+"], Lyrisist: "+lyricist.toString()+", Duration: "+to_string(duration)+", Rating: "+to_string(rating)+", Genre: "+genre;	
	return to_str;

}

string Song::toStringForFile(){
			string to_str=to_string(uniqueSongID)+","+title+","	;
			for(int i=0;i<3;i++){// for each artist
				if(artistList[i].getFirstName()!="" && artistList[i].getLastName()!=""){//if artist exists
					if(i>0){
						to_str=to_str+","+artistList[i].toString();
					}
					else{
						to_str=to_str+artistList[i].toString();
					}
					
				}
			}	
			to_str=to_str+","+lyricist.toString()+","+to_string(duration)+","+to_string(rating)+","+genre;	
			return to_str;
		}

