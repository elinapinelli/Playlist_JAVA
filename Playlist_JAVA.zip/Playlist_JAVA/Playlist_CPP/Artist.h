#ifndef PLAYLIST_CPP_ARTIST_H
#define PLAYLIST_CPP_ARTIST_H

using namespace std; //gia na doulepsei string, to_string
#include <string>//gia na doulepsei string

class Artist {
	private:
		string firstName;
		string lastName;
	public:
		 //A.b Constructor
		Artist(string first,string last) ;
		//A.b Empty constractor (if doesn't exist, Artist cannot passed to Song constructor)
		Artist(); 
		//A.c
		void setFirstName(string first);
		
		//A.c
		string getFirstName() ;
		//A.c
		void setLastName(string last);
		//A.c
		string getLastName();
		//A.d
		string getLastNameAndFirstLetter();
		
		string toString();
};

#endif
