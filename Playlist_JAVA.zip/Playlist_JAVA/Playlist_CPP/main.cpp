#include <iostream>
#include <stdio.h>
#include <stdlib.h>
////#include <string.h>
using namespace std; //gia na doulepsei string, to_string
#include <string>//gia na doulepsei string
// #include <cstring>
#include <vector>
#include <iostream>
#include <fstream>
#include "Artist.h"
#include "Song.h"
#include <bits/stdc++.h>  // library in order to split the string/text

int main(int argc, char** argv) {
	 // Object to read from file
	vector<Song> playlist;
    ifstream file_obj2;
	file_obj2.open("playlist.txt");
	string line;
	int r_id;
	string r_title;
	while(std::getline(file_obj2, line)){
		stringstream ss(line);//it creats the flow per line
		vector<string> v;//inside the vector will we put the text that they will be slpited by the comma
		while (ss.good()) {//it means that inside the flow are data
			string substr;//it refers to each data that are splitted by the comma
			getline(ss, substr, ',');//it takes one by one the attributes from the line and it puts it to the substring
			v.push_back(substr);//add the attributes to the vector per line
		}
		r_id=stoi(v.at(0));//convert string to int
		r_title=v.at(1);
		int r_duration;
	double r_rating;
	string r_genre;
	Artist r_artistList[3];
	if (v.size()==7){//the song has 1 artist
		vector<string> v2;//the vector that we will put the first name and the last name of the artist
		stringstream ss2(v.at(2));//it creats the flow per artist
		while (ss2.good()) {//it means that inside the flow are data
			string substr2;//it refers to each data that are splitted by the space
			getline(ss2, substr2, ' ');//it takes the first name and the last name of the artist
			v2.push_back(substr2);//add the first name and the last name of the artist
		}
		
		vector<string> v3;//the vector that we will put the first name and the last name of the lyricist
		stringstream ss3(v.at(3));//it creats the flow per lyricist
		while (ss3.good()) {//it means that inside the flow are data
			string substr3;//it refers to each data that are splitted by the space
			getline(ss3, substr3, ' ');//it takes the first name and the last name of the lyricist
			v3.push_back(substr3);//add the first name and the last name of the lyricist
		}
		 r_duration=stoi(v.at(4));//convert string to int
		 r_rating=stod(v.at(5));//convert string to double
		 r_genre=v.at(6);
		 Artist r_newArtist(v2.at(0),v2.at(1));
		 r_artistList[0]=r_newArtist;
		 Artist r_lyricist(v3.at(0),v3.at(1));
		 Song r_newSong(r_id,r_title,r_artistList,r_lyricist,r_duration,r_rating,r_genre);
         playlist.push_back(r_newSong);
	}
	else if(v.size()==8){//the song has 2 artists
		vector<string> v2;//the vector that we will put the first name and the last name of the artist
		stringstream ss2(v.at(2));//it creats the flow per artist
		while (ss2.good()) {//it means that inside the flow are data
			string substr2;//it refers to each data that are splitted by the space
			getline(ss2, substr2, ' ');//it takes the first name and the last name of the artist
			v2.push_back(substr2);//add the first name and the last name of the artist
		}
		
		vector<string> v4;//the vector that we will put the first name and the last name of the second artist
		stringstream ss4(v.at(3));//it creats the flow per artist
		while (ss4.good()) {//it means that inside the flow are data
			string substr4;//it refers to each data that are splitted by the space
			getline(ss4, substr4, ' ');//it takes the first name and the last name of the artist
			v4.push_back(substr4);//add the first name and the last name of the artist
		}
		
		vector<string> v3;//the vector that we will put the first name and the last name of the lyricist
		stringstream ss3(v.at(4));//it creats the flow per lyricist
		while (ss3.good()) {//it means that inside the flow are data
			string substr3;//it refers to each data that are splitted by the space
			getline(ss3, substr3, ' ');//it takes the first name and the last name of the lyricist
			v3.push_back(substr3);//add the first name and the last name of the lyricist
		}
		 r_duration=stoi(v.at(5));//convert string to int
		 r_rating=stod(v.at(6));//convert string to double
		 r_genre=v.at(7);
		 Artist r_newArtist(v2.at(0),v2.at(1));
		 r_artistList[0]=r_newArtist;
		 
		 Artist r_newArtist2(v4.at(0),v4.at(1));
		 r_artistList[1]=r_newArtist2;
		 
		 Artist r_lyricist(v3.at(0),v3.at(1));
		 Song r_newSong(r_id,r_title,r_artistList,r_lyricist,r_duration,r_rating,r_genre);
         playlist.push_back(r_newSong);
		
	}
	else if(v.size()==9){//the song has 3 artists
		vector<string> v2;//the vector that we will put the first name and the last name of the artist
		stringstream ss2(v.at(2));//it creats the flow per artist
		while (ss2.good()) {//it means that inside the flow are data
			string substr2;//it refers to each data that are splitted by the space
			getline(ss2, substr2, ' ');//it takes the first name and the last name of the artist
			v2.push_back(substr2);//add the first name and the last name of the artist
		}
		
		vector<string> v4;//the vector that we will put the first name and the last name of the second artist
		stringstream ss4(v.at(3));//it creats the flow per artist
		while (ss4.good()) {//it means that inside the flow are data
			string substr4;//it refers to each data that are splitted by the space
			getline(ss4, substr4, ' ');//it takes the first name and the last name of the artist
			v4.push_back(substr4);//add the first name and the last name of the artist
		}
		
		vector<string> v5;//the vector that we will put the first name and the last name of the third artist
		stringstream ss5(v.at(4));//it creats the flow per artist
		while (ss5.good()) {//it means that inside the flow are data
			string substr5;//it refers to each data that are splitted by the space
			getline(ss5, substr5, ' ');//it takes the first name and the last name of the artist
			v5.push_back(substr5);//add the first name and the last name of the artist
		}
		
		vector<string> v3;//the vector that we will put the first name and the last name of the lyricist
		stringstream ss3(v.at(5));//it creats the flow per lyricist
		while (ss3.good()) {//it means that inside the flow are data
			string substr3;//it refers to each data that are splitted by the space
			getline(ss3, substr3, ' ');//it takes the first name and the last name of the lyricist
			v3.push_back(substr3);//add the first name and the last name of the lyricist
		}
		 r_duration=stoi(v.at(6));//convert string to int
		 r_rating=stod(v.at(7));//convert string to double
		 r_genre=v.at(8);
		 
		 Artist r_newArtist(v2.at(0),v2.at(1));
		 r_artistList[0]=r_newArtist;
		 
		 Artist r_newArtist2(v4.at(0),v4.at(1));
		 r_artistList[1]=r_newArtist2;
		 
		 Artist r_newArtist3(v5.at(0),v5.at(1));
		 r_artistList[2]=r_newArtist3;
		 
		 Artist r_lyricist(v3.at(0),v3.at(1));
		 Song r_newSong(r_id,r_title,r_artistList,r_lyricist,r_duration,r_rating,r_genre);
         playlist.push_back(r_newSong);
	}
	
	}

	
	
	
	int choice;
	
	do{	
		cout <<""<< endl;
		cout <<"\nMenu"<< endl;
		cout <<"----"<< endl;
		cout <<"0.Exit & Save file"<< endl;
		cout <<"1.Add new song"<< endl;
		cout <<"2.Search for song by ID"<< endl;
		cout <<"3.Search for song by title"<< endl;
		cout <<"4.Update the rating of a song"<< endl;
		cout <<"5.Update the duration of a song"<< endl;
		cout <<"6.Display the playlist"<< endl;
		cout <<"7.Save file"<< endl;
		cout <<"Please select a number:"<< endl;
		cin>>choice;
		
		if (choice == 0) {
			// Object to write in file
			ofstream file_obj;
			file_obj.open("playlist.txt");
			for(int i=0; i<playlist.size();i++){
			 	if (i==0){//first song
					file_obj.write(playlist.at(i).toStringForFile().data(), playlist.at(i).toStringForFile().size());
		 		}
				else{
					string new_line="\n"+playlist.at(i).toStringForFile();
					file_obj.write(new_line.data(), new_line.size());
		
			 	}
			}
			file_obj.close();
			cout<<"File saved and exiting."<<endl;
		} else if (choice == 1) {
		    cout <<"\nAdd new Song"<< endl;
			cout <<"------------"<< endl;
			cout <<"Add a unique ID"<< endl;
			int uniqueID;
			cin>>uniqueID;
			cout <<"Add a title"<< endl;
			string title;
			cin>>title;
			int artists;
			do {
				cout <<"How many artists have this song?:"<< endl;
				cin>>artists;
				if (artists <= 0 || artists > 3) {
					cout <<"You gave wrong number of asrists. Please, give from 1 to 3 artists per song"<< endl;
				}
			} while (artists <= 0 || artists > 3);
			Artist artistList[3];
			string lastName;
			string firstName;
			for(int i=0; i<artists; i++){
				cout <<"Please add last name for artist " <<i+1<< endl;
				cin>>lastName;
				cout <<"Please add first name for artist " <<i+1<< endl;
				cin>>firstName;
				Artist newArtist(firstName,lastName);
				artistList[i]=newArtist;	
			}
			
			string lastNameLyricist;
			string firstNameLyricist;
			cout <<"Please add last name for lyricist " << endl;
			cin>>lastNameLyricist;
			cout <<"Please add first name for lyricist " << endl;
            cin>>firstNameLyricist;
            Artist lyricist(firstNameLyricist,lastNameLyricist);
            int duration;
            cout <<"Please add the duration " << endl;
            cin>>duration;
            double rating;
            cout <<"Please add the rating " << endl;
            cin>>rating;
            string genre;
            cout <<"Please add the genre " << endl;
            cin>>genre;
            Song newSong(uniqueID,title,artistList,lyricist,duration,rating,genre);
            playlist.push_back(newSong);
            
		} else if (choice == 2) {
			cout <<"\nSearch by ID."<< endl;
			cout <<"------------"<< endl;
			cout <<"Please enter a song ID in order to search it:"<< endl;
		    int songID;
		    cin>>songID;
		    int counter = 0;
			for (int i = 0; i < playlist.size(); i++) {
				if (songID == playlist.at(i).getUniqueSongID()) {// song was found
					cout <<playlist.at(i).toString()<< endl;
					counter = counter + 1;
				}
			}
			if (counter == 0) {
				cout <<"The song was not found!"<< endl;
			}
		} else if (choice == 3) {
		    cout <<"\nSearch by title."<< endl;
			cout <<"------------"<< endl;
			cout <<"Please enter a title in order to search it:"<< endl;
		    string title;
		    cin>>title;
		    int counter = 0;
			for (int i = 0; i < playlist.size(); i++) {
				if (title == playlist.at(i).getTitle()) {// song was found
					cout <<playlist.at(i).toString()<< endl;
					counter = counter + 1;
				}
			}
			if (counter == 0) {
				cout <<"The song was not found!"<< endl;
			}
		} else if (choice == 4) {
			cout <<"\nUpdate the rating of a song."<< endl;
			cout <<"------------"<< endl;
			for(int i=0; i<playlist.size();i++){
				cout <<i+1<<"."<<playlist.at(i).toString()<< endl;
			}
			cout <<"Please select a number of song to change the rating:"<< endl;
			int choice4;
			do {
				cin>>choice4;
				if (choice4 <= 0 || choice4 > playlist.size()) {
					cout <<"Wrong choice. Plese select  again between 1-" << playlist.size()<< endl;
				}
			} while (choice4 <= 0 || choice4 > playlist.size());
			cout <<"Please enter the new rating to update"<< endl;
			double rating;
			cin>>rating;
			playlist.at(choice4 - 1).setRating(rating);
		} else if (choice == 5) {
			cout <<"\nUpdate the duration(seconds) of a song."<< endl;
			cout <<"------------"<< endl;
				for(int i=0; i<playlist.size();i++){
				cout <<i+1<<"."<<playlist.at(i).toString()<< endl;
			}
			cout <<"Please select a number of song to change the duration:"<< endl;
			int choice4;
			do {
				cin>>choice4;
				if (choice4 <= 0 || choice4 > playlist.size()) {
					cout <<"Wrong choice. Plese select  again between 1-" << playlist.size()<< endl;
				}
			} while (choice4 <= 0 || choice4 > playlist.size());
			cout <<"Please enter the new duration to update"<< endl;
			int duration;
			cin>>duration;
			playlist.at(choice4 - 1).setDuration(duration);
		} else if (choice == 6) {
			cout <<"\nAll songs."<< endl;
			cout <<"------------"<< endl;
			for(int i=0; i<playlist.size();i++){
				cout<<i+1<<"." <<playlist.at(i).toString()<< endl;
			}
		} else if (choice == 7) {
			cout <<"\nSave to file."<< endl;
			cout <<"------------"<< endl;
			// Object to write in file
			ofstream file_obj;
			file_obj.open("playlist.txt");
			for(int i=0; i<playlist.size();i++){
			 	if (i==0){//first song
					file_obj.write(playlist.at(i).toStringForFile().data(), playlist.at(i).toStringForFile().size());
		 		}
				else{
					string new_line="\n"+playlist.at(i).toStringForFile();
					file_obj.write(new_line.data(), new_line.size());
		
			 	}
			}
			file_obj.close();
		} else {
			cout <<"Wrong choice. Please select a number from 0 to 7."<< endl;
		}	
	}while(choice != 0);
	
	

	return 0;
}
