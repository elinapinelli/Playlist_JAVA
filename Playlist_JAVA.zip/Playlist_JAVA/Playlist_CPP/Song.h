#ifndef PLAYLIST_CPP_SONG_H
#define PLAYLIST_CPP_SONG_H

using namespace std; //gia na doulepsei string, to_string
#include <string>//gia na doulepsei string
#include "Artist.h"

class Song{
	private://B.a
		int uniqueSongID;
		string title;		
		Artist lyricist;
		int duration;
		double rating;
		string genre;
		Artist artistList[3];
	public:
		//B.b.1 Constructor
		Song(int ID, string t, Artist aL[3], Artist l, int d,double r, string g);
		//B.b.1 Constructor
		Song();
		void setUniqueSongID(int ID);
		
		int getUniqueSongID() ;
		
		void setTitle(std::string t) ;
		
		string getTitle() ;
		
		void setArtistList(Artist aL[3]) ;
		
		Artist* getArtistList() ;
		
		void setLyricist( Artist l) ;
		
		Artist getLyricist();
		
		void setDuration(int d) ;
		
		int getDuration();
		
		void setRating(double r);
		
		double getRating() ;
		
		void setGenre(std::string g);
		
		string getGenre();
		
		string toString() ;
		
		string toStringForFile();
};

#endif
