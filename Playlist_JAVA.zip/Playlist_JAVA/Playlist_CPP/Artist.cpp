#include "Artist.h"
using namespace std; //gia na doulepsei string, to_string
#include <string>//gia na doulepsei string

Artist::Artist(string first,string last) { //A.b Constructor
	firstName=first;
	lastName=last;
}
Artist::Artist() { //A.b Empty constractor (if doesn't exist, Artist cannot passed to Song constructor)
}

void Artist::setFirstName(string first)	{//A.c
	firstName=first;
}

string Artist::getFirstName() {//A.c
	return firstName;
}

void Artist::setLastName(string last) {//A.c
	lastName=last;
}	

string Artist::getLastName() {//A.c
	return lastName;
}

string Artist::getLastNameAndFirstLetter(){//A.d
	return lastName+" "+firstName.at(0);
}

string Artist::toString() {					
	return lastName+" "+firstName;

}

