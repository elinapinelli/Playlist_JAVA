
public class Playlist_Java {

	public static void main(String[] args) {
		Menu my_menu = new Menu();
	}
}
