import java.io.Serializable;
import java.util.Arrays;

public class Song implements Serializable { // B.a
	private int uniqueSongID;
	private String title;
	private Artist artistList[];
	private Artist lyricist;
	private int duration;
	private double rating;
	private String genre;

	public Song(int uniqueSongID, String title, Artist[] artistList, Artist lyricist, int duration, double rating,
			String genre) { // B.b.1
		this.uniqueSongID = uniqueSongID;
		this.title = title;
		this.artistList = artistList;
		this.lyricist = lyricist;
		this.duration = duration;
		this.rating = rating;
		this.genre = genre;
	}

	public void addArtist(Artist artistToSong) {// B.b.3
		if (artistList.length == 3) {
			System.out.println("Error, you can't add more than three artists");
		} else {
			//
			Artist newArtistList[] = new Artist[artistList.length + 1]; // create a new artist list
			for (int i = 0; i < artistList.length; i++) { // fill the new artist list from the existing artist list
				newArtistList[i] = artistList[i];
			}
			newArtistList[artistList.length] = artistToSong;// we add he new artist to the new list
			artistList = newArtistList;// we replace the existing artist list with the new artist list
		}
	}

	public int getUniqueSongID() { // B.b.2
		return uniqueSongID;
	}

	public void setUniqueSongID(int uniqueSongID) {
		this.uniqueSongID = uniqueSongID;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Artist[] getArtistList() {
		return artistList;
	}

	public void setArtistList(Artist[] artistList) {
		this.artistList = artistList;
	}

	public Artist getLyricist() {
		return lyricist;
	}

	public void setLyricist(Artist lyricist) {
		this.lyricist = lyricist;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public double getRating() {
		return rating;
	}

	public void setRating(double rating) {
		this.rating = rating;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	@Override
	public String toString() { // B.b.4
		return "Song : uniqueSongID=" + uniqueSongID + ", title=" + title + ", artistList="
				+ Arrays.toString(artistList) + ", lyricist=" + lyricist + ", duration=" + duration + ", rating="
				+ rating + ", genre=" + genre;
	}

	public boolean compareSong(Song songToCompare) { // B.b.5
		if (uniqueSongID == songToCompare.getUniqueSongID()) {
			return true;
		} else {
			return false;
		}

	}

}
