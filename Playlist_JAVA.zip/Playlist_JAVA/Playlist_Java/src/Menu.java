import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Scanner;

public class Menu implements Serializable {
	private int choice;
	private ArrayList<Song> playlist;
	private Scanner sc;
	private String fileName = "Playlist.ser";

	public Menu() {
		File playlist_file = new File(fileName);
		if (playlist_file.exists()) {
			loadFile();// load playlist from file
		} else {
			this.playlist = new ArrayList<Song>();// create empty list
		}

		sc = new Scanner(System.in);// scanner that reads from terminal
		do {
			display_menu();
			if (choice == 0) {
				saveFile();
				System.out.println("File Saved. Program exits...");
				System.exit(0);// programm ends
			} else if (choice == 1) {
				System.out.println("\nAdd new Song");
				System.out.println("------------");
				int uniqueID = get_song_unique_id();
				String title = get_song_title();
				Artist[] artistlist = get_song_artist_list();
				Artist lyricist = get_song_lyricist();
				int duration = get_song_duration();
				double rating = get_song_rating();
				String genre = get_song_genre();
				Song newSong = new Song(uniqueID, title, artistlist, lyricist, duration, rating, genre);
				playlist.add(newSong);
			} else if (choice == 2) {
				System.out.println("\nSearch by ID.");
				System.out.println("------------");
				search_song_ID();
			}

			else if (choice == 3) {
				System.out.println("\nSearch by title.");
				System.out.println("------------");
				search_song_Title();
			}

			else if (choice == 4) {
				System.out.println("\nUpdate the rating of a song.");
				System.out.println("------------");
				update_The_Rating();
			}
			
			else if (choice == 5) {
				System.out.println("\nUpdate the duration of a song.");
				System.out.println("------------");
				update_The_Duration();

			}

			else if (choice == 6) {
				System.out.println("\nAll songs.");
				System.out.println("------------");
				display_all_songs();

			}

			else if (choice == 7) {
				System.out.println("\nSave to file.");
				System.out.println("------------");
				saveFile();

			}
		} while (choice != 0);
	}

	public void display_menu() {

		do {
			System.out.println("\nMenu");
			System.out.println("----");
			System.out.println("0.Exit & Save file");
			System.out.println("1.Add new song");
			System.out.println("2.Search for song by ID");
			System.out.println("3.Search for song by title");
			System.out.println("4.Update the rating of a song");
			System.out.println("5.Update the duration of a song");
			System.out.println("6.Display the playlist");
			System.out.println("7.Save file");
			System.out.println("Please select a number:");
			choice = sc.nextInt();
			sc.nextLine();// to get the enter
			if (choice < 0 || choice > 7) {
				System.out.println("Wrong choice. Please select a number from 0 to 7.");
			}
		} while (choice < 0 || choice > 7);

	}

	public int get_song_unique_id() {
		System.out.println("Please add the unique ID of the song:");
		int uniqueID;
		uniqueID = sc.nextInt();
		sc.nextLine();// to get the enter
		return uniqueID;
	}

	public String get_song_title() {
		System.out.println("Please add the title of the song:");
		String title;
		title = sc.nextLine();
		return title;
	}

	public Artist[] get_song_artist_list() {
		int artists;
		do {
			System.out.println("How many artists have this song?:");
			artists = sc.nextInt();
			sc.nextLine();
			if (artists <= 0 || artists > 3) {
				System.out.println("You gave wrong number of asrists. Please, give from 1 to 3 artists per song");
			}
		} while (artists <= 0 || artists > 3);
		Artist artistList[] = new Artist[artists];// empty artsist list
		int counter = 0;
		String first_name;
		String last_name;
		for (int i = 0; i < artists; i++) {
			counter = i + 1;
			System.out.println("Please enter first name of artist number " + counter);
			first_name = sc.nextLine();
			System.out.println("Please enter last name of artist number " + counter);
			last_name = sc.nextLine();
			Artist newArtist = new Artist(first_name, last_name);
			artistList[i] = newArtist;
		}
		return artistList;
	}

	public Artist get_song_lyricist() {
		String first_name;
		String last_name;
		System.out.println("Please enter first name of lyricist");
		first_name = sc.nextLine();
		System.out.println("Please enter last name of lyricist");
		last_name = sc.nextLine();
		Artist newLyricist = new Artist(first_name, last_name);
		return newLyricist;
	}

	public int get_song_duration() {
		System.out.println("Please add the duration of the song (seconds):");
		int duration;
		duration = sc.nextInt();
		sc.nextLine();// to get the enter
		return duration;
	}

	public double get_song_rating() {
		System.out.println("Please add the rating of the song:");
		double rating;
		rating = sc.nextDouble();
		sc.nextLine();// to get the enter
		return rating;
	}

	public String get_song_genre() {
		System.out.println("Please add the genre of the song:");
		String genre;
		genre = sc.nextLine();
		return genre;
	}

	public void search_song_ID() {// searching for the song ID
		System.out.println("Please enter a song ID in order to search it:");
		int songID;
		songID = sc.nextInt();
		sc.nextLine();// to get the enter
		int counter = 0;
		for (int i = 0; i < playlist.size(); i++) {
			if (songID == playlist.get(i).getUniqueSongID()) {// song was found
				System.out.println(playlist.get(i));
				counter = counter + 1;
			}
		}
		if (counter == 0) {
			System.out.println("The song was not found!");
		}

	}

	public void search_song_Title() {// searching for the song title
		System.out.println("Please enter a song title in order to search it:");
		String songTitle;
		songTitle = sc.nextLine();
		int counter = 0;
		for (int i = 0; i < playlist.size(); i++) {
			if (songTitle.equals(playlist.get(i).getTitle())) {// song was found
				System.out.println(playlist.get(i));
				counter = counter + 1;
			}
		}
		if (counter == 0) {
			System.out.println("The song was not found!");
		}

	}

	public void display_all_songs() {
		int numberOfSongs;
		for (int i = 0; i < playlist.size(); i++) {
			numberOfSongs = i + 1;
			System.out.println(numberOfSongs + "." + playlist.get(i));
		}
	}

	public void update_The_Rating() {// updating the rating of the song
		display_all_songs();
		System.out.println("Please select a number of song to change the rating:");
		int choice4;
		do {
			choice4 = sc.nextInt();
			sc.nextLine();// to get the enter
			if (choice4 <= 0 || choice4 > playlist.size()) {
				System.out.println("Wrong choice. Plese select  again between 1-" + playlist.size());
			}
		} while (choice4 <= 0 || choice4 > playlist.size());
		System.out.println("Please enter the new rating to update");
		double rating;
		rating = sc.nextDouble();
		playlist.get(choice4 - 1).setRating(rating);
	}

	public void update_The_Duration() {// updating the duration of the song
		display_all_songs();
		System.out.println("Please select a number of song to change the duration:");
		int choice4;
		do {
			choice4 = sc.nextInt();
			sc.nextLine();// to get the enter
			if (choice4 <= 0 || choice4 > playlist.size()) {
				System.out.println("Wrong choice. Plese select  again between 1-" + playlist.size());
			}
		} while (choice4 <= 0 || choice4 > playlist.size());
		System.out.println("Please enter the new duration to update");
		int duration;
		duration = sc.nextInt();
		playlist.get(choice4 - 1).setDuration(duration);
	}

	public void saveFile() {// save playlist to file
		try {
			FileOutputStream file_to_write = new FileOutputStream(fileName);
			ObjectOutputStream out_stream = new ObjectOutputStream(file_to_write);
			out_stream.writeObject(playlist);
			out_stream.close();
			file_to_write.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void loadFile() {// load playlist from file
		try {
			FileInputStream file_to_load = new FileInputStream(fileName);
			ObjectInputStream in_stream = new ObjectInputStream(file_to_load);
			playlist = (ArrayList<Song>) in_stream.readObject();// casting
			in_stream.close();
			file_to_load.close();
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
}
