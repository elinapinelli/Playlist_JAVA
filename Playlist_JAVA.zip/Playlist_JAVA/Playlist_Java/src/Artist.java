import java.io.Serializable;

public class Artist implements Serializable { // A.a
	private String firstName;
	private String lastName;

	public Artist(String firstName, String lastName) { // A.b
		this.firstName = firstName;
		this.lastName = lastName;
	}

	public String getFirstName() { // A.c
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getLastNameAndFirstLetter() { // A.d
		String firstLetterLastName;
		firstLetterLastName = lastName + " " + firstName.charAt(0);
		return firstLetterLastName;
	}

	@Override
	public String toString() {
		return firstName + " " + lastName;
	}

}
